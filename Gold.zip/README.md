# 实时金价浮窗显示浏览器插件

数据来源：<https://www.exchangerates.org.uk/commodities/live-gold-prices.html?iso=USD>

